

const LANGUAGES = [
  ['Afrikaans','af'],['Albanian','sq'],['Amharic','am'],['Arabic','ar'],['Armenian','hy'],
  ['Azerbaijani','az'],['Basque','eu'],['Belarusian','be'],['Bengali','bn'],['Bosnian','bs'],
  ['Bulgarian','bg'],['Catalan','ca'],['Chinese (Simplified)','zh-CN'],['Chinese (Traditional)','zh-TW'],
  ['Croatian','hr'],['Czech','cs'],['Danish','da'],['Dutch','nl'],['English','en'],['Estonian','et'],
  ['Finnish','fi'],['French','fr'],['Galician','gl'],['Georgian','ka'],['German','de'],['Greek','el'],
  ['Gujarati','gu'],['Haitian Creole','ht'],['Hebrew','he'],['Hindi','hi'],['Hungarian','hu'],
  ['Icelandic','is'],['Indonesian','id'],['Irish','ga'],['Italian','it'],['Japanese','ja'],
  ['Kannada','kn'],['Kazakh','kk'],['Korean','ko'],['Latvian','lv'],['Lithuanian','lt'],
  ['Macedonian','mk'],['Malay','ms'],['Malayalam','ml'],['Maltese','mt'],['Marathi','mr'],
  ['Mongolian','mn'],['Nepali','ne'],['Norwegian','no'],['Persian','fa'],['Polish','pl'],
  ['Portuguese','pt'],['Punjabi','pa'],['Romanian','ro'],['Russian','ru'],['Serbian','sr'],
  ['Sinhalese','si'],['Slovak','sk'],['Slovenian','sl'],['Somali','so'],['Spanish','es'],
  ['Swahili','sw'],['Swedish','sv'],['Tamil','ta'],['Telugu','te'],['Thai','th'],['Turkish','tr'],
  ['Ukrainian','uk'],['Urdu','ur'],['Uzbek','uz'],['Vietnamese','vi'],['Welsh','cy'],['Yoruba','yo'],
  ['Zulu','zu']
];

const srcLang        = document.getElementById('srcLang');
const tgtLang        = document.getElementById('tgtLang');
const srcText        = document.getElementById('srcText');
const outputText     = document.getElementById('outputText');
const translateBtn   = document.getElementById('translateBtn');
const charCount      = document.getElementById('charCount');
const infoBar        = document.getElementById('infoBar');
const errorMsg       = document.getElementById('errorMsg');
const historySection = document.getElementById('historySection');
const historyList    = document.getElementById('historyList');

// Populate dropdowns
srcLang.add(new Option('Detect Language', 'auto'));
LANGUAGES.forEach(([name, code]) => {
  srcLang.add(new Option(name, code));
  tgtLang.add(new Option(name, code));
});
tgtLang.value = 'fr';

let activeChips = new Set();
let history     = [];
let isSpeaking  = false;

document.querySelectorAll('.option-chip').forEach(chip => {
  chip.addEventListener('click', () => {
    const key = chip.id.replace('chip-', '');
    if (activeChips.has(key)) { activeChips.delete(key); chip.classList.remove('active'); }
    else { activeChips.add(key); chip.classList.add('active'); }
  });
});

srcText.addEventListener('input', () => { charCount.textContent = srcText.value.length; });

document.getElementById('clearBtn').addEventListener('click', () => {
  srcText.value = ''; charCount.textContent = '0';
  outputText.textContent = 'Translation will appear here…';
  outputText.className = 'output-text empty';
  infoBar.style.display = 'none'; errorMsg.style.display = 'none';
});

document.getElementById('pasteBtn').addEventListener('click', async () => {
  try { const t = await navigator.clipboard.readText(); srcText.value = t.slice(0,5000); charCount.textContent = srcText.value.length; } catch(e) {}
});

document.getElementById('copyBtn').addEventListener('click', () => {
  const t = outputText.textContent;
  if (t && !outputText.classList.contains('empty')) {
    navigator.clipboard.writeText(t).catch(()=>{});
    const btn = document.getElementById('copyBtn');
    btn.style.color = '#1D9E75'; setTimeout(() => btn.style.color = '', 1200);
  }
});

document.getElementById('speakBtn').addEventListener('click', () => {
  const t = outputText.textContent;
  if (!t || outputText.classList.contains('empty') || outputText.classList.contains('loading')) return;
  if (isSpeaking) { speechSynthesis.cancel(); isSpeaking = false; return; }
  const utt = new SpeechSynthesisUtterance(t);
  utt.lang = tgtLang.value; utt.onend = () => { isSpeaking = false; };
  isSpeaking = true; speechSynthesis.speak(utt);
});

document.getElementById('swapBtn').addEventListener('click', () => {
  if (srcLang.value === 'auto') return;
  const sv = srcLang.value, tv = tgtLang.value;
  srcLang.value = tv; tgtLang.value = sv;
  if (!outputText.classList.contains('empty') && !outputText.classList.contains('loading')) {
    const t = outputText.textContent;
    srcText.value = t; charCount.textContent = t.length;
    outputText.textContent = 'Translation will appear here…'; outputText.className = 'output-text empty';
  }
});

srcText.addEventListener('keydown', e => { if ((e.ctrlKey||e.metaKey) && e.key==='Enter') translate(); });
translateBtn.addEventListener('click', translate);

function buildPrompt(src, srcL, tgtL) {
  const tgtName = LANGUAGES.find(l => l[1]===tgtL)?.[0] || tgtL;
  const srcName = srcL==='auto' ? 'the detected language' : (LANGUAGES.find(l=>l[1]===srcL)?.[0]||srcL);
  const lines = [`Translate the following text from ${srcName} to ${tgtName}.`];
  if (activeChips.has('formal'))  lines.push('Use a formal, professional register.');
  if (activeChips.has('casual'))  lines.push('Use a casual, friendly tone.');
  if (activeChips.has('simple'))  lines.push('Simplify the language for easy understanding.');
  if (activeChips.has('explain')) lines.push('After the translation, add a brief note explaining any idioms or culturally specific phrases.');
  if (srcL==='auto') { lines.push(''); lines.push('At the very end, on a new line, write exactly: [DETECTED: <language name>]'); }
  lines.push(''); lines.push('Provide ONLY the translation. No preamble, no quotes wrapping the result.');
  lines.push(''); lines.push(`Text to translate:\n${src}`);
  return lines.join('\n');
}

async function translate() {
  const text = srcText.value.trim();
  if (!text) return;

  errorMsg.style.display = 'none'; infoBar.style.display = 'none';
  outputText.textContent = 'Translating…'; outputText.className = 'output-text loading';
  translateBtn.disabled = true;
  translateBtn.innerHTML = '<span class="spinner"></span> Translating…';

  try {
    const res = await fetch('/translate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
    text: text,
    target: tgtLang.value
})
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.error?.message || 'Translation failed');

    let result = data.content.map(b => b.text||'').join('').trim();
    let detected = null;
    const detMatch = result.match(/\[DETECTED:\s*(.+?)\]\s*$/m);
    if (detMatch) { detected = detMatch[1].trim(); result = result.replace(detMatch[0],'').trim(); }

    outputText.textContent = result; outputText.className = 'output-text';
    if (detected) { infoBar.innerHTML = `<span class="badge detected">🌐 Detected: ${detected}</span>`; infoBar.style.display = 'flex'; }

    const tgtName = LANGUAGES.find(l=>l[1]===tgtLang.value)?.[0]||tgtLang.value;
    const srcName = detected||(LANGUAGES.find(l=>l[1]===srcLang.value)?.[0]||'Auto');
    addHistory(text, result, srcName, tgtName);

  } catch(e) {
    outputText.textContent = 'Translation will appear here…'; outputText.className = 'output-text empty';
    errorMsg.textContent = '⚠️ ' + (e.message||'Something went wrong. Please try again.');
    errorMsg.style.display = 'block';
  } finally {
    translateBtn.disabled = false;
    translateBtn.innerHTML = `<svg viewBox="0 0 24 24" style="width:17px;height:17px;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round"><path d="M3 5h12M9 3v2m1.048 3.938A9.957 9.957 0 0112 12a9.957 9.957 0 01-1.048 4.062m0-8.124a9.927 9.927 0 000 8.124m0-8.124l-4.914 8.124M21 5h-7M15 3v2m1.048 3.938A9.957 9.957 0 0117 12a9.957 9.957 0 01-1.048 4.062m0-8.124a9.927 9.927 0 000 8.124m0-8.124l-4.914 8.124"/></svg> Translate`;
  }
}

function addHistory(src, tgt, srcName, tgtName) {
  history.unshift({ src: src.slice(0,120), tgt: tgt.slice(0,120), srcName, tgtName, time: new Date() });
  if (history.length > 6) history.pop();
  renderHistory();
}

function renderHistory() {
  historyList.innerHTML = '';
  if (!history.length) { historySection.style.display = 'none'; return; }
  historySection.style.display = 'block';
  history.forEach((item, i) => {
    const elapsed = Math.round((Date.now()-item.time)/60000);
    const timeStr = elapsed < 1 ? 'just now' : elapsed+'m ago';
    const el = document.createElement('div');
    el.className = 'history-item';
    el.innerHTML = `<div class="history-pair"><div class="history-src">${esc(item.src)}${item.src.length>=120?'…':''}</div><div class="history-tgt">${esc(item.tgt)}${item.tgt.length>=120?'…':''}</div></div><div class="history-meta">${item.srcName} → ${item.tgtName} · ${timeStr}</div>`;
    el.addEventListener('click', () => { srcText.value = history[i].src; charCount.textContent = srcText.value.length; });
    historyList.appendChild(el);
  });
}

document.getElementById('clearHistory').addEventListener('click', () => {
  history = []; historySection.style.display = 'none'; historyList.innerHTML = '';
});

function esc(s) { return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }