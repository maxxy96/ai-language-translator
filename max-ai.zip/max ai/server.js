const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = 5000;

// MIME types
const MIME = {
  '.html': 'text/html',
  '.css': 'text/css',
  '.js': 'application/javascript',
  '.json': 'application/json',
};

// Create server
const server = http.createServer((req, res) => {

  // Enable CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  // Handle OPTIONS request
  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }
  if (req.method === 'POST' && req.url === '/translate') {

    let body = '';

    req.on('data', chunk => {
      body += chunk;
    });

    req.on('end', async () => {

      try {

        const payload = JSON.parse(body);

        console.log(payload);
        console.log(payload.text);
        const text = payload.text || '';
        const target = payload.target || 'fr';
        const apiUrl =
          `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=en|${target}`;

        fetch(apiUrl)
          .then(response => response.json())
          .then(data => {

            const translated =
              data.responseData.translatedText;

            // Send response
            res.writeHead(200, {
              'Content-Type': 'application/json'
            });

            res.end(JSON.stringify({
              content: [
                {
                  text: translated
                }
              ]
            }));

          })
          .catch(error => {

            console.error(error);

            res.writeHead(500, {
              'Content-Type': 'application/json'
            });

            res.end(JSON.stringify({
              error: {
                message: error.message
              }
            }));

          });

      } catch (error) {

        console.error(error);

        res.writeHead(400, {
          'Content-Type': 'application/json'
        });

        res.end(JSON.stringify({
          error: {
            message: 'Invalid request'
          }
        }));

      }

    });

    return;
  }
  let filePath = req.url === '/'
    ? '/index.html'
    : req.url;

  filePath = path.join(__dirname, filePath);

  fs.readFile(filePath, (err, data) => {

    if (err) {

      res.writeHead(404, {
        'Content-Type': 'text/plain'
      });

      res.end('404 Not Found');
      return;
    }

    const ext = path.extname(filePath);

    res.writeHead(200, {
      'Content-Type': MIME[ext] || 'text/plain'
    });

    res.end(data);

  });

});
server.listen(PORT, () => {

  console.log('');
  console.log('✅ MaxAI Translator Running');
  console.log(`🌐 Open: http://localhost:${PORT}`);
  console.log('');

});